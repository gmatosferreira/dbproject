﻿namespace Funcionarios
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.title = new System.Windows.Forms.Label();
            this.statsGroup = new System.Windows.Forms.GroupBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.statsBibliotecaLabel = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.statsTurmasLabel = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.statsNaoDocentesLabel = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.statsEstudantesLabel = new System.Windows.Forms.Label();
            this.statsFuncionarios = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.statsDocentesLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuGroup = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.menuDocentesPanel = new System.Windows.Forms.Panel();
            this.menuDocentesLabel = new System.Windows.Forms.Label();
            this.menuDocentesImagem = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.logo = new System.Windows.Forms.PictureBox();
            this.statsGroup.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.statsFuncionarios.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuGroup.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.menuDocentesPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuDocentesImagem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.Location = new System.Drawing.Point(85, 34);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(367, 31);
            this.title.TabIndex = 0;
            this.title.Text = "Sistema de Gestão Escolar";
            // 
            // statsGroup
            // 
            this.statsGroup.Controls.Add(this.panel8);
            this.statsGroup.Controls.Add(this.panel7);
            this.statsGroup.Controls.Add(this.panel6);
            this.statsGroup.Controls.Add(this.panel5);
            this.statsGroup.Controls.Add(this.statsFuncionarios);
            this.statsGroup.Location = new System.Drawing.Point(25, 105);
            this.statsGroup.Name = "statsGroup";
            this.statsGroup.Size = new System.Drawing.Size(752, 120);
            this.statsGroup.TabIndex = 2;
            this.statsGroup.TabStop = false;
            this.statsGroup.Text = "Estatísticas";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.Window;
            this.panel8.Controls.Add(this.pictureBox9);
            this.panel8.Controls.Add(this.label12);
            this.panel8.Controls.Add(this.statsBibliotecaLabel);
            this.panel8.Location = new System.Drawing.Point(585, 30);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(135, 74);
            this.panel8.TabIndex = 12;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox9.Image = global::Funcionarios.Properties.Resources.Biblioteca;
            this.pictureBox9.InitialImage = null;
            this.pictureBox9.Location = new System.Drawing.Point(11, 9);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(44, 52);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 9;
            this.pictureBox9.TabStop = false;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(61, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 28);
            this.label12.TabIndex = 8;
            this.label12.Text = "Biblioteca Escolar";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // statsBibliotecaLabel
            // 
            this.statsBibliotecaLabel.AutoSize = true;
            this.statsBibliotecaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statsBibliotecaLabel.Location = new System.Drawing.Point(59, 14);
            this.statsBibliotecaLabel.Name = "statsBibliotecaLabel";
            this.statsBibliotecaLabel.Size = new System.Drawing.Size(42, 26);
            this.statsBibliotecaLabel.TabIndex = 8;
            this.statsBibliotecaLabel.Text = "XX";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Window;
            this.panel7.Controls.Add(this.pictureBox8);
            this.panel7.Controls.Add(this.label8);
            this.panel7.Controls.Add(this.statsTurmasLabel);
            this.panel7.Location = new System.Drawing.Point(444, 30);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(135, 74);
            this.panel7.TabIndex = 11;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox8.Image = global::Funcionarios.Properties.Resources.Turmas;
            this.pictureBox8.InitialImage = null;
            this.pictureBox8.Location = new System.Drawing.Point(9, 9);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(44, 52);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 9;
            this.pictureBox8.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(61, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Turmas";
            // 
            // statsTurmasLabel
            // 
            this.statsTurmasLabel.AutoSize = true;
            this.statsTurmasLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statsTurmasLabel.Location = new System.Drawing.Point(59, 14);
            this.statsTurmasLabel.Name = "statsTurmasLabel";
            this.statsTurmasLabel.Size = new System.Drawing.Size(42, 26);
            this.statsTurmasLabel.TabIndex = 8;
            this.statsTurmasLabel.Text = "XX";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Window;
            this.panel6.Controls.Add(this.pictureBox7);
            this.panel6.Controls.Add(this.label);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.statsNaoDocentesLabel);
            this.panel6.Location = new System.Drawing.Point(157, 30);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(135, 74);
            this.panel6.TabIndex = 10;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox7.Image = global::Funcionarios.Properties.Resources.Nao_Docente;
            this.pictureBox7.InitialImage = null;
            this.pictureBox7.Location = new System.Drawing.Point(9, 14);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(46, 47);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 10;
            this.pictureBox7.TabStop = false;
            // 
            // label
            // 
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(53, 40);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(79, 25);
            this.label.TabIndex = 9;
            this.label.Text = "Não Docentes";
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(61, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Docentes";
            // 
            // statsNaoDocentesLabel
            // 
            this.statsNaoDocentesLabel.AutoSize = true;
            this.statsNaoDocentesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statsNaoDocentesLabel.Location = new System.Drawing.Point(59, 14);
            this.statsNaoDocentesLabel.Name = "statsNaoDocentesLabel";
            this.statsNaoDocentesLabel.Size = new System.Drawing.Size(42, 26);
            this.statsNaoDocentesLabel.TabIndex = 8;
            this.statsNaoDocentesLabel.Text = "XX";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Window;
            this.panel5.Controls.Add(this.pictureBox6);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.statsEstudantesLabel);
            this.panel5.Location = new System.Drawing.Point(298, 30);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(135, 74);
            this.panel5.TabIndex = 9;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox6.Image = global::Funcionarios.Properties.Resources.Estudantes1;
            this.pictureBox6.InitialImage = null;
            this.pictureBox6.Location = new System.Drawing.Point(9, 9);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(44, 52);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 9;
            this.pictureBox6.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(61, 46);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Estudantes";
            // 
            // statsEstudantesLabel
            // 
            this.statsEstudantesLabel.AutoSize = true;
            this.statsEstudantesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statsEstudantesLabel.Location = new System.Drawing.Point(59, 14);
            this.statsEstudantesLabel.Name = "statsEstudantesLabel";
            this.statsEstudantesLabel.Size = new System.Drawing.Size(42, 26);
            this.statsEstudantesLabel.TabIndex = 8;
            this.statsEstudantesLabel.Text = "XX";
            // 
            // statsFuncionarios
            // 
            this.statsFuncionarios.BackColor = System.Drawing.SystemColors.Window;
            this.statsFuncionarios.Controls.Add(this.label1);
            this.statsFuncionarios.Controls.Add(this.statsDocentesLabel);
            this.statsFuncionarios.Controls.Add(this.pictureBox1);
            this.statsFuncionarios.Location = new System.Drawing.Point(16, 30);
            this.statsFuncionarios.Name = "statsFuncionarios";
            this.statsFuncionarios.Size = new System.Drawing.Size(135, 74);
            this.statsFuncionarios.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(61, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Docentes";
            // 
            // statsDocentesLabel
            // 
            this.statsDocentesLabel.AutoSize = true;
            this.statsDocentesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statsDocentesLabel.Location = new System.Drawing.Point(59, 14);
            this.statsDocentesLabel.Name = "statsDocentesLabel";
            this.statsDocentesLabel.Size = new System.Drawing.Size(42, 26);
            this.statsDocentesLabel.TabIndex = 8;
            this.statsDocentesLabel.Text = "XX";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = global::Funcionarios.Properties.Resources.Funcionários;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(14, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // menuGroup
            // 
            this.menuGroup.Controls.Add(this.panel4);
            this.menuGroup.Controls.Add(this.panel3);
            this.menuGroup.Controls.Add(this.panel2);
            this.menuGroup.Controls.Add(this.panel1);
            this.menuGroup.Controls.Add(this.menuDocentesPanel);
            this.menuGroup.Location = new System.Drawing.Point(25, 231);
            this.menuGroup.Name = "menuGroup";
            this.menuGroup.Size = new System.Drawing.Size(752, 207);
            this.menuGroup.TabIndex = 4;
            this.menuGroup.TabStop = false;
            this.menuGroup.Text = "Menu";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Window;
            this.panel4.Controls.Add(this.pictureBox5);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel4.Location = new System.Drawing.Point(576, 48);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(101, 106);
            this.panel4.TabIndex = 9;
            this.panel4.Click += new System.EventHandler(this.menuBibliotecaPanel_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox5.Image = global::Funcionarios.Properties.Resources.Biblioteca;
            this.pictureBox5.InitialImage = null;
            this.pictureBox5.Location = new System.Drawing.Point(29, 15);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(44, 52);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 32);
            this.label6.TabIndex = 7;
            this.label6.Text = "Biblioteca Escolar";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Window;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel3.Location = new System.Drawing.Point(444, 48);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(101, 106);
            this.panel3.TabIndex = 8;
            this.panel3.Click += new System.EventHandler(this.menuTurmasPanel_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Turmas";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox4.Image = global::Funcionarios.Properties.Resources.Turmas;
            this.pictureBox4.InitialImage = null;
            this.pictureBox4.Location = new System.Drawing.Point(30, 15);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(44, 52);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel2.Location = new System.Drawing.Point(197, 48);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(99, 106);
            this.panel2.TabIndex = 7;
            this.panel2.Click += new System.EventHandler(this.menuNaoDocentesPanel_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(10, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 37);
            this.label4.TabIndex = 7;
            this.label4.Text = "Não Docentes";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox3.Image = global::Funcionarios.Properties.Resources.Nao_Docente;
            this.pictureBox3.InitialImage = null;
            this.pictureBox3.Location = new System.Drawing.Point(28, 15);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(46, 47);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Location = new System.Drawing.Point(320, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(101, 106);
            this.panel1.TabIndex = 6;
            this.panel1.Click += new System.EventHandler(this.menuEstudantesPanel_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Estudantes";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.menuEstudantesPanel_Click);

            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::Funcionarios.Properties.Resources.Estudantes1;
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(30, 15);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 52);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.menuEstudantesPanel_Click);

            // 
            // menuDocentesPanel
            // 
            this.menuDocentesPanel.BackColor = System.Drawing.SystemColors.Window;
            this.menuDocentesPanel.Controls.Add(this.menuDocentesLabel);
            this.menuDocentesPanel.Controls.Add(this.menuDocentesImagem);
            this.menuDocentesPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuDocentesPanel.Location = new System.Drawing.Point(66, 48);
            this.menuDocentesPanel.Name = "menuDocentesPanel";
            this.menuDocentesPanel.Size = new System.Drawing.Size(101, 106);
            this.menuDocentesPanel.TabIndex = 5;
            this.menuDocentesPanel.Click += new System.EventHandler(this.menuFuncionariosPanel_Click);
            // 
            // menuDocentesLabel
            // 
            this.menuDocentesLabel.AutoSize = true;
            this.menuDocentesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuDocentesLabel.Location = new System.Drawing.Point(17, 80);
            this.menuDocentesLabel.Name = "menuDocentesLabel";
            this.menuDocentesLabel.Size = new System.Drawing.Size(68, 17);
            this.menuDocentesLabel.TabIndex = 7;
            this.menuDocentesLabel.Text = "Docentes";
            this.menuDocentesLabel.Click += new System.EventHandler(this.menuFuncionariosPanel_Click);
            // 
            // menuDocentesImagem
            // 
            this.menuDocentesImagem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.menuDocentesImagem.Image = global::Funcionarios.Properties.Resources.Funcionários;
            this.menuDocentesImagem.InitialImage = null;
            this.menuDocentesImagem.Location = new System.Drawing.Point(28, 17);
            this.menuDocentesImagem.Name = "menuDocentesImagem";
            this.menuDocentesImagem.Size = new System.Drawing.Size(44, 52);
            this.menuDocentesImagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menuDocentesImagem.TabIndex = 5;
            this.menuDocentesImagem.TabStop = false;
            this.menuDocentesImagem.Click += new System.EventHandler(this.menuFuncionariosPanel_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 454);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(256, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "© Gonçalo matos (92972) e Maria Inês (93320) 2020";
            // 
            // logo
            // 
            this.logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.logo.Image = global::Funcionarios.Properties.Resources.Livro;
            this.logo.InitialImage = null;
            this.logo.Location = new System.Drawing.Point(25, 24);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(44, 52);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo.TabIndex = 1;
            this.logo.TabStop = false;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 476);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.menuGroup);
            this.Controls.Add(this.statsGroup);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.title);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Home";
            this.Text = "Sistema de Gestão Escolar";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statsGroup.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.statsFuncionarios.ResumeLayout(false);
            this.statsFuncionarios.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuGroup.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.menuDocentesPanel.ResumeLayout(false);
            this.menuDocentesPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuDocentesImagem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.GroupBox statsGroup;
        private System.Windows.Forms.GroupBox menuGroup;
        private System.Windows.Forms.PictureBox menuDocentesImagem;
        private System.Windows.Forms.Panel menuDocentesPanel;
        private System.Windows.Forms.Label menuDocentesLabel;
        private System.Windows.Forms.Label statsDocentesLabel;
        private System.Windows.Forms.Panel statsFuncionarios;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label statsEstudantesLabel;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label statsBibliotecaLabel;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label statsTurmasLabel;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label statsNaoDocentesLabel;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label10;
    }
}

